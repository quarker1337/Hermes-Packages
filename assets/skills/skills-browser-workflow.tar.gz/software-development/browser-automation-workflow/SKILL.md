---
name: browser-automation-workflow
description: "Use when interacting with websites through Hermes browser tools. Provides the general navigate/snapshot/interact/verify loop, tool-selection guidance, console checks, visual checks, and common browser automation pitfalls."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [browser, web, automation, testing, workflow]
    related_skills: [dogfood]
---

# Browser Automation Workflow

## Overview

This skill is the generic operating procedure for Hermes browser tools. Use it when a task requires opening a real page, clicking through dynamic UI, filling forms, inspecting JavaScript errors, or visually checking rendered output.

The browser tools are not a replacement for faster text tools. Prefer `web_search` for finding URLs and `web_extract` for plain article/document extraction. Reach for `browser_*` when the task needs interaction, JavaScript-rendered state, screenshots, console logs, login flows, forms, or visual layout verification.

## When to Use

Use this skill for:

- Navigating and inspecting websites or local HTML files.
- Testing forms, buttons, links, menus, modals, auth flows, and other interactive UI.
- Verifying rendered layouts, screenshots, visual regressions, or accessibility-tree structure.
- Debugging JavaScript console errors or failed client-side API calls.
- Working with dynamic pages where `web_extract` misses content.
- Capturing evidence before reporting what happened.

Do not use browser automation for:

- Static text extraction from simple pages, Markdown, JSON, PDFs, raw files, or docs endpoints — use `web_extract`, `terminal`, or file tools.
- API calls that need headers or tokens — use `terminal` with `curl` or a small script.
- Broad web research where search/extract can answer faster.
- Personal/private browser tabs unless the user explicitly asks and the task requires them.

## Core Loop

Follow this loop for most browser tasks:

1. Find or receive the target URL.
   - If the user gave a URL, navigate directly.
   - If the user gave a site/name, use `web_search` first to avoid guessing the URL.
2. Navigate:
   - `browser_navigate(url="https://example.com")`
3. Inspect structure:
   - Use the compact snapshot from `browser_navigate`, then call `browser_snapshot()` after page-changing interactions.
   - Use `browser_snapshot(full=true)` only when the compact tree omits important content.
4. Check the console early:
   - `browser_console(clear=true)` after initial navigation if you are testing/debugging.
   - `browser_console()` after significant clicks, form submissions, or route changes.
5. Interact through stable refs:
   - `browser_click(ref="@eN")`
   - `browser_type(ref="@eN", text="...")`
   - `browser_press(key="Enter")`, `Tab`, `Escape`, arrows, etc.
   - `browser_scroll(direction="down")` for content below the fold.
6. Verify after each meaningful action:
   - Refresh the accessibility tree with `browser_snapshot()`.
   - Use `browser_vision(question="...", annotate=true)` when visual layout or spatial reasoning matters.
   - Re-check console/network symptoms with `browser_console()`.
7. Report only grounded observations:
   - Include URL, action taken, observed result, console errors, and screenshot path when relevant.

## Tool Selection Reference

| Tool | Use for |
|------|---------|
| `browser_navigate` | Start a browser session and load a URL. Required before most browser tools. |
| `browser_snapshot` | Read the accessibility tree and discover refs such as `@e5`. |
| `browser_click` | Click an element by snapshot ref. |
| `browser_type` | Clear and type into an input field. |
| `browser_press` | Submit forms, keyboard navigation, shortcuts, Escape/Tab/Enter flows. |
| `browser_scroll` | Reveal content above or below the viewport. |
| `browser_back` | Return to previous browser history entry. |
| `browser_get_images` | List images and alt text on the current page. |
| `browser_vision` | Screenshot plus visual analysis, with optional element annotations. |
| `browser_console` | JavaScript console, uncaught errors, failed client-side calls, or DOM inspection via expression. |
| `browser_cdp` / `browser_dialog` | Lower-level diagnostics or dialog handling when normal tools are insufficient. |

## Search/Extract vs Browser

Use the cheapest tool that can answer correctly:

- `web_search`: discover official URLs, current pages, docs, news, and external references.
- `web_extract`: read static pages, docs, articles, PDFs, raw text/JSON/XML/CSV, or content that does not require interaction.
- `browser_*`: interact with live UI, execute client-side JavaScript, inspect rendered state, capture screenshots, handle forms, or debug console/runtime behavior.
- `terminal`/scripts: authenticated APIs, custom headers, bulk downloads, repeatable scraping, or machine-readable endpoints.

If `browser_navigate` text tells you a raw endpoint or PDF would be better handled by `web_extract` or `curl`, switch tools instead of forcing browser automation.

## Visual Verification

Use `browser_vision` when text snapshots are insufficient:

- Layout checks: overlapping text, clipped buttons, bad spacing, broken images, dark/light contrast.
- CAPTCHA/visual challenge identification. Do not try to bypass; explain limitations and ask the user if human input is required.
- Canvas/WebGL/SVG/chart output that is not visible in the accessibility tree.
- Element-position reasoning with `annotate=true`, then click using the mapped `@eN` ref.

For evidence, record the returned screenshot path. In CLI sessions, state the path plainly; in messaging platforms that support inline media, use the platform’s expected media syntax.

## Console and DOM Diagnostics

Console checks catch high-value silent failures:

- After navigation: `browser_console(clear=true)` to start with a clean buffer.
- After interactions: `browser_console()` to catch new errors.
- For DOM state: `browser_console(expression="document.title")` or targeted expressions such as `document.querySelectorAll('button').length`.

Keep expressions small and read-only unless the task explicitly requires changing page state.

## Forms and Multi-Step Flows

- Snapshot first; do not guess refs.
- Fill required fields one at a time with `browser_type`.
- Use `browser_press(key="Tab")` to test keyboard navigation when accessibility matters.
- Test both valid and invalid submissions when debugging validation.
- After submission, verify URL, visible state, console output, and any success/error messages.
- For auth/payment/destructive flows, stop before irreversible actions unless the user explicitly approves the exact action.

## Local HTML and App Testing

For local files or dev servers:

1. Start the server with `terminal(background=true)` only if it is long-lived; use `notify_on_complete=true` for bounded builds/tests.
2. Verify readiness through logs or a health check before navigating.
3. Navigate to `http://127.0.0.1:<port>/...` or `file:///absolute/path/index.html`.
4. Use browser snapshot, console, and vision to verify the real rendered result.

## Common Pitfalls

1. Navigating before searching when the URL is unknown.
   - Use `web_search` to find the official target first.

2. Reading only the snapshot and skipping console.
   - Many web-app failures are invisible until `browser_console()` shows a JavaScript error or failed client call.

3. Trusting visual impressions without a screenshot.
   - Use `browser_vision` for visual claims and include the screenshot path when reporting issues.

4. Clicking stale refs after the page changes.
   - Call `browser_snapshot()` again after route changes, form submissions, modal opens/closes, or significant DOM updates.

5. Using browser for raw text, APIs, or documents.
   - Prefer `web_extract`, `terminal`, or file tools for Markdown, JSON, CSV, XML, PDFs, and API endpoints.

6. Claiming success without verification.
   - After every meaningful action, verify the resulting page state, URL, console output, or server-side state if available.

7. Triggering side effects too casually.
   - For purchases, account changes, deletes, sends, publishes, or irreversible actions, confirm the scope before clicking the final action.

## Verification Checklist

- [ ] URL or local path was grounded, not guessed.
- [ ] Browser navigation completed and the page state was inspected.
- [ ] Relevant refs came from the latest snapshot.
- [ ] Console was checked for debugging/testing tasks.
- [ ] Visual claims were backed by `browser_vision` when the snapshot could not prove them.
- [ ] Significant interactions were followed by snapshot/console/visual verification.
- [ ] Any side-effectful final action had explicit user approval.
